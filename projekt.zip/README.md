# BezpieczenstwoProjekt

Szyfrowanie obrazów z użyciem DES i SDES

Stan prac: 29.04.2020

1. Wybór pliku z komputera
2. Podgląd pliku
3. Możliwosc podania 'secret-key' wykorzystywanego do szyfrowania
4. Zaszyfrowanie zdjęcia (na chwilę obecną do szyfrowania użyty jest algorytm z biblioteki cryptoJs)
5. Po zaszyfrowaniu zdjęcie zostaje pobrane

Kolejne etapy

1. Mozliwosc deszyfrowania zdjecia
2. Progress bar
3. Implementacja własna algorytmu szyfrującego
