import {Component, OnInit} from '@angular/core';
import * as CryptoJS from "crypto-js";
import {saveAs} from 'file-saver';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.scss']
})
export class AppComponent implements OnInit {
  fileSrc: string;
  progress: number;
  infoMessage: any;
  isUploading: boolean = false;
  file: File;
  imageUrl: string | ArrayBuffer = "https://bulma.io/images/placeholders/480x480.png";
  fileName: string = "No file selected";
  private secretKey = '123'

  constructor() {
  }

  ngOnInit() {
  }

  onChange(file: File) {
    if (file) {
      this.fileName = file.name;
      this.file = file;

      const reader = new FileReader();
      reader.readAsDataURL(file);

      reader.onload = event => {
        this.imageUrl = reader.result;
      };
    }
  }

  onAction() {
    if (this.file) {
      var reader = new FileReader();
      reader.onload = (event: any) => {
        const fileText = event.target.result;
        this.fileSrc = fileText;
        const fileHeader = fileText.substr(0, 64);
        const fileData = fileText.substr(64, fileText.length - 1);
        const encryptedFileData = this.encrypt(fileData);
        const newFile = fileHeader + fileData;
        this.save(newFile)
      };
      reader.readAsDataURL(this.file);
    }
  }

  save(value: string) {
    var file = new File([this.dataURItoBlob(value)], 'imageFileName.png');
    saveAs(file);
  }

  base64ToHex(text: string) {
    let result = '';
    for (let i = 0; i < text.length; i++) {
      const hex = text.charCodeAt(i).toString(16);
      result += (hex.length === 2 ? hex : '0' + hex);
    }
    return result.toUpperCase();
  }

  hexToBase64(hexstring) {
    return btoa(hexstring.match(/\w{2}/g).map(a => String.fromCharCode(parseInt(a, 16))).join(""));
  }

  dataURItoBlob(dataURI) {
    const byteString = atob(dataURI.split(',')[1]);
    const ab = new ArrayBuffer(byteString.length);
    const ia = new Uint8Array(ab);
    for (let i = 0; i < byteString.length; i++) {
      ia[i] = byteString.charCodeAt(i);
    }
    return new Blob([ab], {type: 'image/png'});
  }

  encrypt(fileData: string) {
    return CryptoJS.DES.encrypt(fileData, this.secretKey).toString();
  }

  decrypt(fileData: string) {
    return CryptoJS.DES.decrypt(fileData, this.secretKey).toString();
  }
}
